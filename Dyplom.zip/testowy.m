% clc
% close all;
% clear

function r = coderand() %#codegen
r = rand();